var message_container = document.getElementById("messages-container");
message_container.scrollTop = message_container.scrollHeight;
